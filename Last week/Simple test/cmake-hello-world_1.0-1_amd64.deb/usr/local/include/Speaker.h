#include <stdio.h>
#include <iostream>

namespace Hello {

  class Speaker {
    
    public:
      void sayHello();
  };
}
