#include "Speaker.h"

using namespace Hello;
using namespace std;

namespace Hello {
  void Speaker::sayHello() {
    cout << "Hello, world!\n";
  }
}
